# EdTech Playwright Java Automation Framework

This framework covers:
- Admin Course Creation
- Course Publishing
- User Purchase Flow
- JWT Authentication API Testing
- Role-based Validation
- CI Ready Structure

Tech Stack:
- Playwright Java
- TestNG
- Maven
- Git
